<main>
    <div class="page-banner">
        <div>
            <h1>TIN TỨC</h1>
            <div class="breadcrumb">
                <a href="/">TRANG CHỦ</a>
                <span>/</span>
                <a href="#">TIN TỨC</a>
            </div>
        </div>
    </div>
    <!-- Tin nổi bật -->
    <section class="featured-news container">
        <div class="main-news">
            <div class="news-card large">
                <img src="img/bus.png" alt="Bến xe khách">
                <div class="news-content">
                    <h1>TIN MỚI NHẤT</h1>
                    <h2>BẾN XE KHÁCH VĨNH NIỆM LÀ BẾN XE ĐẦU TIÊN CỦA HẢI PHÒNG...</h2>
                    <p>Lorem ipsum is simply dummy text of the printing and typesetting industry...</p>
                    <a href="#" class="read-more"><i class="fa-solid fa-circle-arrow-right"></i>XEM THÊM</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Grid tin tức -->
    <section class="news-grid container">
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>
        <div class="news-card">
            <img src="img/bus1.png" alt="Bến xe">
            <div class="news-content">
                <h3>VÌ SAO TP.HCM DI DỜI 3 TUYẾN XE KHÁCH TỪ BẾN XE MIỀN ĐÔNG CŨ SANG BẾN MỚI</h3>
                <p>Theo đó là một nguồn thông báo trong trong...</p>
            </div>
        </div>  
        
    </section>

    <!-- Phân trang -->
    <?php
        $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $items_per_page = 9; 
        $total_news = 10; 
        $total_pages = ceil($total_news / $items_per_page);
        if ($current_page < 1) $current_page = 1;
        if ($current_page > $total_pages) $current_page = $total_pages;
    ?>

    <div class="pagination container">
        <?php if($current_page > 1): ?>
            <a href="?page=<?php echo $current_page - 1; ?>">&larr;</a>
        <?php endif; ?>
        
        <?php for($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" 
                class="<?php echo $current_page == $i ? 'active' : ''; ?>">
                <?php echo str_pad($i, 2, '0', STR_PAD_LEFT); ?>
            </a>
        <?php endfor; ?>
        
        <?php if($current_page < $total_pages): ?>
            <a href="?page=<?php echo $current_page + 1; ?>" class="next">&#8594;</a>
        <?php endif; ?>
    </div>
</main>
