<header>
        <div class="header-top">
            <div class="container">
                <a href="/index.php" class="logo">
                    <img src="/img/logo.png" alt="Mỹ Duyên Logo">
                </a>
                <div class="header-right">
                    <div class="number-contact-info">
                        <i class="fas fa-phone"></i>
                        <span>02862 77 55 44</span>
                    </div>
                    <div class="header-buttons">
                        <a href="thongtinve.php" class="btn btn-primary">TRA CỨU VÉ</a>
                        <a href="tracuudonhang.php" class="btn btn-primary">TRA CỨU ĐƠN HÀNG</a>
                    </div>
                </div>
            </div>
        </div>
        <nav class="main-nav">
            <div class="container">
                <ul class="nav-links">
                    <li><a href="index.php">TRANG CHỦ</a></li>
                    <li><a href="about.php">GIỚI THIỆU <i class="fa-solid fa-chevron-right" ></i></a>
                        <ul class="sub-menu">
                            <li><a href="about.php">VỀ CHÚNG TÔI</a></li>
                            <li><a href="hethong.php">HỆ THỐNG VĂN PHÒNG</a></li>
                        </ul>
                    </li>
                    <li><a href="dichvu1.php">DỊCH VỤ <i class="fa-solid fa-chevron-right"></i></a>
                        <ul class="sub-menu">
                            <li><a href="dichvu1.php">DỊCH VỤ VẬN TẢI HÀNH KHÁCH</a></li>
                            <li><a href="dichvu2.php">DỊCH VỤ VẬN TẢI HÀNG HÓA</a></li>
                        </ul>
                    </li>
                    <li><a href="thongtinve.php">TRA CỨU <i class="fa-solid fa-chevron-right"></i></a>
                        <ul class="sub-menu">
                            <li><a href="thongtinve.php">TRA CỨU VÉ</a></li>
                            <li><a href="tracuudonhang.php">TRA CỨU ĐƠN HÀNG</a></li>
                        </ul>
                    </li>
                    <li><a href="tintuc.php">TIN TỨC</a></li>
                    <li><a href="lienhe.php">LIÊN HỆ</a></li>
                    <li><a href="tuyendung.php">TUYỂN DỤNG</a></li>
                </ul>
                <button class="search-toggle">
                    <i class="fas fa-search"></i>
                </button>
            </div>
        </nav>
    </header>